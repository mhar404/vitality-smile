<?php

namespace App\Policies;

use App\Models\Patient;
use App\Models\User;
use Illuminate\Auth\Access\Response;

class PatientPolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return true; // We will filter the query in the controller for patients
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, Patient $patient): bool
    {
        if (in_array($user->role, ['admin', 'secretary', 'dentist', 'staff'])) {
            return true;
        }

        // Patient can only view their own profile
        return $user->role === 'patient' && $patient->user_id === $user->id;
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return in_array($user->role, ['admin', 'secretary', 'dentist', 'staff']);
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, Patient $patient): bool
    {
        return in_array($user->role, ['admin', 'secretary', 'dentist', 'staff']);
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, Patient $patient): bool
    {
        // Dentist and Secretary (Admin) can delete (archive).
        return in_array($user->role, ['admin', 'secretary', 'dentist']);
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(User $user, Patient $patient): bool
    {
        return in_array($user->role, ['admin', 'secretary', 'dentist']);
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(User $user, Patient $patient): bool
    {
        return in_array($user->role, ['admin', 'secretary']); // Assuming Admin/Secretary
    }
}
